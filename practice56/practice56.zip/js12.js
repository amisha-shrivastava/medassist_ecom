function  call() {
    if(pwd.value==cpwd.value){
        msg.src="tick.png"
    }
    else
    {
        msg.src="cross.png"
    }


}