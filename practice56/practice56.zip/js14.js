function  call() {
   // alert(male.checked)
    if(male.checked)
    { result.innerHTML=male.value}
    else if(female.checked)
    { result.innerHTML=female.value}


}