function call() {
  result.innerHTML=txt.value

}