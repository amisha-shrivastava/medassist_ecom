function  call() {
    if(red.checked)
    {
      txt.color="red"}
   else if(green.checked)
    {
      txt.color="green"}
   else if(blue.checked)
    {
      txt.color="blue"}




}