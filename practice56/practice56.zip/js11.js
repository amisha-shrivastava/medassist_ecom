function  call() {
    if(pwd.value==cpwd.value){
        msg.innerHTML="<font color='green'>Password Matched</font>"
    }
    else
    {
        msg.innerHTML="<font color='red'>Password Not Matched</font>"
    }


}