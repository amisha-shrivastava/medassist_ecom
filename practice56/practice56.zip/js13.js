function  call() {
   if(pwd.type=="password")
   {
       pwd.type="text"
       eye.src="open.png"
   }
   else
   {
       pwd.type="password"
       eye.src="close.png"


   }



}